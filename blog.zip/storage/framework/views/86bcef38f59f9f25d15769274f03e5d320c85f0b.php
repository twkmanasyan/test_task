<?php $__env->startSection("title"); ?>Register <?php $__env->stopSection(); ?>
<?php $__env->startSection("page-scripts"); ?>
    <script src="<?php echo e(asset("dist/js/jquery.maskedinput.js")); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <div class="auth-wrapper">
        <div class="register-form">
            <form action="<?php echo e(route("register")); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-2">
                            <label style="color:white" for="first_name" class="form-label">First Name</label>
                            <input
                                type="text"
                                class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="first_name"
                                name="first_name"
                                placeholder="John"
                            >

                            <?php if($errors->has('first_name')): ?>
                                <span class="text-danger"><?php echo e($errors->first('first_name')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-2">
                            <label style="color:white" for="last_name" class="form-label">Last Name</label>
                            <input
                                type="text"
                                class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="last_name"
                                name="last_name"
                                placeholder="Smith"
                            >

                            <?php if($errors->has('last_name')): ?>
                                <span class="text-danger"><?php echo e($errors->first('last_name')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-2">
                            <label style="color:white" for="birth_date" class="form-label">Birth Date</label>
                            <input
                                type="text"
                                class="form-control <?php $__errorArgs = ['birth_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="birth_date"
                                name="birth_date"
                                placeholder="01/01/1995"
                            >

                            <?php if($errors->has('birth_date')): ?>
                                <span class="text-danger"><?php echo e($errors->first('birth_date')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-2">
                            <label style="color:white" for="phone" class="form-label">Phone</label>
                            <input
                                type="tel"
                                class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="phone"
                                name="phone"
                                placeholder="(991)-222-3333"
                            >

                            <?php if($errors->has('phone')): ?>
                                <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="mb-2">
                            <label for="email" class="form-label">Email</label>
                            <input
                                type="email"
                                class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="email"
                                name="email"
                                placeholder="example@mai.ru"
                            >

                            <?php if($errors->has('email')): ?>
                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-2">
                            <label style="color:white" for="password" class="form-label">Password</label>
                            <input
                                type="password"
                                class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="password"
                                name="password"
                                placeholder="****"
                            >

                            <?php if($errors->has('password')): ?>
                                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-2">
                            <label style="color:white" for="confirm_password" class="form-label">Confirm Password</label>
                            <input
                                type="password"
                                class="form-control <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="confirm_password"
                                name="confirm_password"
                                placeholder="****"
                            >

                            <?php if($errors->has('confirm_password')): ?>
                                <span class="text-danger"><?php echo e($errors->first('confirm_password')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="mb-2">
                            <input type="checkbox" class="form-check-input" name="sport_favorite">
                            <label style="color: #ffffff" class="form-check-label">Favorite Sport</label>
                        </div>
                    </div>
                </div>
                <button class="btn btn-success">Register</button>
            </form>
            <p class="mt-2" style="color:#ffffff;">Account Exists? <a href="<?php echo e(route("index")); ?>">Sign In</a></p>

        </div>
    </div>
    <script>
        jQuery(document).ready(function($) {
            $("#phone").mask("(999)-999-9999");
            $("#birth_date").mask("99/99/9999");
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\serv\htdocs\blog\resources\views/auth/register.blade.php ENDPATH**/ ?>