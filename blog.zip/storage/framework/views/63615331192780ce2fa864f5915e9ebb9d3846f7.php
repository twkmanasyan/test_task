<?php $__env->startSection("title"); ?>Student List <?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <div class="container">
        <a href="<?php echo e(route("student-create")); ?>" class="btn btn-primary mt-2">Create New Student</a>
        <h2>USER LIST</h2>
        <?php if (isset($component)) { $__componentOriginal271382f1358b7315b5ae7a740b130b864a84d074 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Messages::class, []); ?>
<?php $component->withName('messages'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal271382f1358b7315b5ae7a740b130b864a84d074)): ?>
<?php $component = $__componentOriginal271382f1358b7315b5ae7a740b130b864a84d074; ?>
<?php unset($__componentOriginal271382f1358b7315b5ae7a740b130b864a84d074); ?>
<?php endif; ?>
        <div class="mt-2 user-list d-flex flex-wrap-wrap">
            <?php if(count($students) == 0): ?>
                <p>Empty List</p>
            <?php else: ?>
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card w-25" style="margin:10px">
                        <div class="card-header">
                            <h4><?php echo e($student->full_name); ?></h4>
                        </div>

                        <div class="card-body">
                            <p>Email` <strong><?php echo e($student->email); ?></strong></p>
                            <p>Phone` <strong><?php echo e($student->phone); ?></strong></p>
                            <a href="<?php echo e(route("student-details", ["id" => $student->id])); ?>" class="btn btn-info">Details</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\serv\htdocs\blog\resources\views/dashboard/students/index.blade.php ENDPATH**/ ?>