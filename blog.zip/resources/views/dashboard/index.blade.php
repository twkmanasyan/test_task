@extends("layouts.app")
@section("title") Dashboard @endsection
@section("content")

@endsection
