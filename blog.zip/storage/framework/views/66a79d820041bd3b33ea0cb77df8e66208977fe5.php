<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php elseif(session('fail')): ?>
    <div class="alert alert-danger"><?php echo e(session('fail')); ?></div>
<?php endif; ?>
<?php /**PATH D:\serv\htdocs\blog\resources\views/components/messages.blade.php ENDPATH**/ ?>