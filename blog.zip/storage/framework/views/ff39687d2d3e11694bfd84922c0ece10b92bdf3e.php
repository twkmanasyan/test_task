<?php use Illuminate\Support\Facades\Auth; ?>

<?php $__env->startSection("title"); ?>
    Student Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <div class="container">
        <a href="<?php echo e(route('student-list')); ?>" class="btn btn-secondary mt-2 mb-2">Back</a>
        <div class="card">
            <div class="card-header">
                <h4><?php echo e($student->full_name); ?></h4>
            </div>
            <div class="card-body">
                <p>Birth Date` <strong><?php echo e($student->b_date); ?></strong></p>
                <p>Phone` <strong><?php echo e($student->phone); ?></strong></p>
                <p>Author` <strong><?php echo e($student->author); ?></strong></p>
                <p>Email` <strong><?php echo e($student->email); ?></strong></p>
                <p>Created At` <strong><?php echo e($student->created_at); ?></strong></p>
                <?php if($student->user_id == Auth::user()->id): ?>
                    <a href="<?php echo e(route("student-edit", ["id" => $student->id])); ?>" class="btn btn-success">Edit</a>
                    <a href="<?php echo e(route("student-delete", ["id" => $student->id])); ?>" class="btn btn-danger">Delete</a>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\serv\htdocs\blog\resources\views/dashboard/students/details.blade.php ENDPATH**/ ?>