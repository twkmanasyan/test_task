<?php $__env->startSection("title"); ?> Edit Student Information
<?php $__env->stopSection(); ?>
<?php $__env->startSection("page-scripts"); ?>
    <script src="<?php echo e(asset("dist/js/jquery.maskedinput.js")); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <div class="container">
        <div class="form w-50">
            <div class="form-title">
                <h2>Student Information</h2>
                <form action="<?php echo e(route("student-update")); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="student_id" value="<?php echo e($student->id); ?>">
                    <div class="mb-2">
                        <label for="full_name" class="form-label">Full Name</label>
                        <input value="<?php echo e($student->name); ?>" class="form-control" type="text" id="full_name" name="full_name" placeholder="John Smith">
                    </div>

                    <div class="mb-2">
                        <label for="birth_date" class="form-label">Birth Date</label>
                        <input value="<?php echo e($student->birth_date); ?>" class="form-control" type="date" id="birth_date" name="birth_date">
                    </div>

                    <div class="mb-2">
                        <label for="email" class="form-label">Email</label>
                        <input value="<?php echo e($student->email); ?>" class="form-control" type="email" id="email" name="email" placeholder="example@mail.ru">
                    </div>

                    <div class="mb-2">
                        <label for="phone" class="form-label">Phone</label>
                        <input value="<?php echo e($student->phone); ?>" class="form-control" type="tel" id="phone" name="phone" placeholder="(999)999-9999">
                    </div>

                    <button class="btn btn-primary">Save Changes</button>
                </form>
            </div>
        </div>
    </div>
    <script>
        jQuery(document).ready(function($) {
            $("#phone").mask("(999)-999-9999");
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\serv\htdocs\blog\resources\views/dashboard/students/edit.blade.php ENDPATH**/ ?>